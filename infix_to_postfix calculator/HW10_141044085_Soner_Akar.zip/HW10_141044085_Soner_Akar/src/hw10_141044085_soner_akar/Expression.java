/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw10_141044085_soner_akar;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Stack;

/**
 *
 * @author soner
 */
public class Expression {
    private ArrayList<String> holdAllInputs;

    /**
     * non-paremeter constructor
     */
    public Expression() {
        this.holdAllInputs = new ArrayList<>();
    }

    /**
     * string parameter constructor that converts string to ArrayList properly
     * @param str is an expression
     */
    public Expression(String str) {

        this.holdAllInputs = new ArrayList<>();

        String arr[] = str.replaceAll("\\s+", "").split("(?<=[-+*/()])|(?=[-+*/()])");

        for (String s : arr) {
            holdAllInputs.add(s);
        }


    }

    /**
     * setter for the operator class
     * @param str takes string array as ArrayList
     *              then copy to member variable
     */
    public void setHoldAllInputs(ArrayList<String> str) {
        this.holdAllInputs = new ArrayList<>(str.size());
        Collections.copy(this.holdAllInputs, str);
    }

    /**
     * @return the last element in the member variable
     */
    public String lastElem() {
        return holdAllInputs.get(holdAllInputs.size() - 1);
    }

    /**
     * getter for parenthesis class
     * @param index specify position
     * @return to get data the specified index
     */
    public String getholdAllInputs(int index) {
        return this.holdAllInputs.get(index);
    }

    /**
     * application of standart ArrayList add method on the class
     * @param str to add new element to member variable
     */
    public void add(String str) {
        this.holdAllInputs.add(str);
    }

    /**
     * convert ArrayList to string properly
     * @return a string that is the expression
     */
    public String convertString() {
        String unified = "";

        for (String s : holdAllInputs) {
            unified += s + " ";
        }

        return unified;
    }

    /**
     * converting infix expression to postfix expression
     * it helps to calculate the expression according to precedence rule
     * @param infix the ordinary expression like writing equation
     * @return a string that is in postfix form
     */
    public String toPostfix(String infix) {

        ArrayList<String> out = new ArrayList<>();
        Stack<Character> arithmeticSymbols = new Stack<>();
        StringBuilder ongoingNumber = new StringBuilder();
        String unified = "";

        char finalDigit;
        char ongoingCharacter;

        for (int i = 0; i < infix.length(); i++) {
            ongoingCharacter = infix.charAt(i);
            if (ongoingCharacter >= '0' && ongoingCharacter <= '9') {
                finalDigit = ongoingCharacter;
                ongoingNumber.append(finalDigit);
            } else {
                if (ongoingNumber.length() > 0) {
                    out.add(ongoingNumber.toString());
                    ongoingNumber = new StringBuilder();
                }
                if (ongoingCharacter == '+' || ongoingCharacter == '-'
                        || ongoingCharacter == '*' || ongoingCharacter == '/') {
                    while (!arithmeticSymbols.empty() &&
                            operatorPrecedence(ongoingCharacter) <= operatorPrecedence(arithmeticSymbols.lastElement())) {
                        out.add(arithmeticSymbols.pop().toString());
                    }
                    arithmeticSymbols.add(ongoingCharacter);

                } else if (ongoingCharacter == '(') {
                    arithmeticSymbols.add(ongoingCharacter);

                } else if (ongoingCharacter == ')') {
                    while (!arithmeticSymbols.empty() && arithmeticSymbols.lastElement() != '(') {
                        out.add(arithmeticSymbols.pop().toString());
                    }
                    arithmeticSymbols.pop();
                }
            }

        }

        if (ongoingNumber.length() > 0) {
            out.add(ongoingNumber.toString());
        }

        while (!arithmeticSymbols.empty()) {
            out.add(arithmeticSymbols.pop().toString());
        }

        for (String s : out)
            unified += s + " ";
        return unified;
    }

    /**
     * specify operator precedence which is done respectively
     * @param op +,-,* or / operator as char
     * @return 1 for +,-, 2 for *,/
     */
    private int operatorPrecedence(char op) {
        int ret = 0;
        if (op == '-' || op == '+') {
            ret = 1;
        } else if (op == '*' || op == '/') {
            ret = 2;
        }
        return ret;
    }

    /**
     * calculates result of converted infix to postfix expression
     * @param postfix is a string that in form of postfix
     * @return result of the expression
     */
    public double postfixEvaluate(String postfix)
    {
        String[] tokens = postfix.trim().split("\\s+"); // skip whitespaces
        Stack<Double> stack = new Stack<>();
        double operand_first;
        double operand_sec;

        if(tokens.length == 0)
            return 0;
        for(String s : tokens)
        {
            // if this token an valid operator, pop two nums, calculate, push back
            if(s.equals("+") || s.equals("-") || s.equals("*") || s.equals("/"))
            {
                operand_sec = stack.pop();
                operand_first = stack.pop();
                if(s.charAt(0) == '+') {
                    stack.push(operand_first + operand_sec);
                    System.out.println(operand_first + " + " + operand_sec + " = " + stack.peek());
                }
                else if(s.charAt(0) == '-') {
                    stack.push(operand_first - operand_sec);
                    System.out.println(operand_first + " - " + operand_sec + " = " + stack.peek());
                }
                else if(s.charAt(0) == '*') {
                    stack.push(operand_first * operand_sec);
                    System.out.println(operand_first + " * " + operand_sec + " = " + stack.peek());
                }
                else if(s.charAt(0) == '/') {
                    stack.push(operand_first / operand_sec);
                    System.out.println((double)operand_first + " / " + operand_sec + " = " + stack.peek());
                }
            }
            else        // It means tokens is a number, push in stack
            {
                double value = Double.parseDouble(s);
                stack.push(value);
            }
        }

        // Finally, pop the last num as result
        return stack.pop();
    }

    /**
     * it is programmer-defined toString method
     * @return prints parenthesis on the screen
     */
    public String toString() {
        String unifiedInfix = this.convertString();
        String postfixForm = this.toPostfix(unifiedInfix);
        return "Reverse Polish Notation Form = " + postfixForm +
                "\nResult of the expression is = " + this.postfixEvaluate(postfixForm) + "\n";
    }

    /**
     * programmer-defined equals method overrided
     * @param o an object of the same class
     * @return true if both of them are same, otherwise false
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        final Expression other = (Expression) o;
        String temp = "";
        for (String s : this.holdAllInputs) {
            temp += s + " ";
        }

        String arr[] = temp.replaceAll("\\s+", "").split("(?<=[-+*/()])|(?=[-+*/()])");
        holdAllInputs.clear();
        for (String s : arr) {
            holdAllInputs.add(s);
        }

        //System.out.println("\n\nthis -> " + this.holdAllInputs.toString());
        //System.out.println("other -> " + other.holdAllInputs.toString());
        return this.holdAllInputs.toString().equals(other.holdAllInputs.toString());
    }

}
