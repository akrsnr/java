/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw10_141044085_soner_akar;

/**
 * If input has a letter to throw exception
 */
public class LetterException extends Exception
{
    //Parameterless Constructor

    /**
     *
     */
        public LetterException() {}

    //Constructor that accepts a message

    /**
     *
     * @param message
     */
        public LetterException(String message)
    {
        super(message);
    }
}
