/*
 * Ben polish notasyonla calistigim icin sizin dediginiz outputu verdiremedim hocam
 */
package hw10_141044085_soner_akar;

/*
 * Soner Akar - 141044085
 * The program provides calculation of an expression in string form
 * by taking into consideration known precedence rule.
 */

import java.util.*;
import java.util.regex.*;


/*
 *  I have researched long time how I can calculate an expression
 *  in string format. There are some websites
 *  http://scriptasylum.com/tutorials/infix_postfix/algorithms/postfix-evaluation/
 *  http://www.leepoint.net/data/expressions/precedence.html
 *  http://www.c4learn.com/data-structure/algorithm-for-infix-to-postfix-conversion-using-stack/
 *  http://www.dotnetperls.com/stringbuilder-java
 *  http://tutorials.jenkov.com/java-exception-handling/basic-try-catch-finally.html
 *  http://www.mathblog.dk/tools/infix-postfix-converter/
 *  http://www.abecedarical.com/javascript/script_reverse_polish.html
 *
 *  For regular expression
 *
 *  http://txt2re.com/
 *  http://regexr.com/
 *  http://www.javatpoint.com/java-regex
 *  http://www.vogella.com/tutorials/JavaRegularExpressions/article.html
 */



public class MyCalc
{
    public static void main(String[] args) {

        // (5 + 3) * 12 / 3
        // = 32
        Scanner scan = new Scanner(System.in);

        Expression exp = new Expression();
        Parenthesis paran = new Parenthesis();
        Operand operands = new Operand();
        Operator operators = new Operator();
        String parts = "";           // Hold every inputs as string
        String unifiedInfix;


        String test = "(12*512)+(443-1)/(27*(8+2*25/14))";
        Expression exp2 = new Expression(test);
        Expression exp3 = new Expression(test);


        System.out.println("Enter your expression, after each operator " +
                "or operand press enter, " +
                "to end the expression press =");

        do {
            System.out.println("Enter your expression element");
            try {
                parts = scan.next();
                if(parts.matches("[a-zA-Z]+")) {
                    throw new LetterException();
                }
                else if(parts.equals("0") && exp.lastElem().equals("/")) {
                    throw new SonersException();
                }
            }
            catch (SonersException e) {
                System.out.println("!!!!Division by zero!!!!");
            }
            catch (LetterException e) {
                System.out.println("It contains letter!");
            }
            catch (Exception e) {
                System.out.println("Be sure entered right content!");
            }
            if (!parts.equals("="))
                exp.add(parts);
        } while (!parts.equals("="));

        unifiedInfix = exp.convertString();
        operands.holdAllNumbers(unifiedInfix);
        operators.holdAllOperators(unifiedInfix);
        paran.holdAllParanthesis(unifiedInfix);

        if (paran.CRP(unifiedInfix)) {   // Check paranthesis entered correctly

            System.out.println(exp);
            System.out.println(operands);
            System.out.println(operators);
            System.out.println(paran);
        }
        else {
            System.out.println("Try to write the expression rightly");
        }

        boolean check = exp2.equals(exp3);
        System.out.println();
        System.out.println("exp2 compare with exp3 same = " + check);

    }
}