/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw10_141044085_soner_akar;

import java.util.*;
import java.util.regex.*;

/**
 *
 * @author soner
 */
public class Operand {
    private ArrayList<Integer> ints;    // Hold int numbers

    /**
     * Non-parameter constructor
     */
    public Operand() {
        this.ints = new ArrayList<>();
    }

    /**
     * setter for the operator class
     * @param num takes integer array as ArrayList
     *              then copy to member variable
     */
    public void setInts(ArrayList<Integer> num) {
        this.ints = new ArrayList<>(ints.size());
        Collections.copy(this.ints, num);
    }

    /**
     * getter for operand class
     * @param index specify position
     * @return to get data the specified index
     */
    public int getInts(int index) {
        return this.ints.get(index);
    }

    /**
     * application of standart ArrayList add method on the class
     * @param num to add new element to member variable
     */
    public void add(int num) {
        this.ints.add(num);
    }

    /**
     * obtain all numbers in a specified expression as a string
     * @param str takes a expression as string to express
     */
    public void holdAllNumbers(String str) {
        List<String> list = new ArrayList<String>();

        Pattern p = Pattern.compile("-?\\d+");
        Matcher m = p.matcher(str);

        while (m.find()) {
            list.add(m.group());
        }

        for(String s : list) {
            ints.add(Integer.valueOf(s));
        }
    }

    /**
     * it is programmer-defined toString method
     * @return prints numbers on the screen
     */
    @Override
    public String toString() {
        return "Numbers in the expression are = " + ints.toString();
    }
}

