/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw10_141044085_soner_akar;

import java.util.*;
import java.util.regex.*;

/**
 *
 * @author soner
 */

public class Operator {
    private ArrayList<Character> opr;    // Hold operands

    /**
     *  Non-parameter constructor
     */
    public Operator() {                 // non-parameter ctor
        this.opr = new ArrayList<>();
    }

    /**
     * setter for the operator class
     * @param chArr takes character array as ArrayList
     *              then copy to member variable
     */
    public void setOpr(ArrayList<Character> chArr) {
        this.opr = new ArrayList<>(chArr.size());
        Collections.copy(this.opr, chArr);
    }

    /**
     * getter for the operator class
     * @param index specify position
     * @return to get data the specified index
     */
    public char getOpr(int index) {
        return this.opr.get(index);
    }

    /**
     * application of standart ArrayList add method on the class
     * @param operand to add new element to member variable
     */
    public void add(char operand) {
        this.opr.add(operand);
    }

    /**
     * obtain all operators in a specified expression as a string
     * @param str takes a expression as string to express
     */
    public void holdAllOperators(String str) {
        List<String> list = new ArrayList<String>();
        Pattern p = Pattern.compile("[\\+\\-\\*\\/]");
        Matcher m = p.matcher(str);
        while (m.find()) {
            list.add(m.group());
        }

        for (String s : list) {
            this.opr.add(s.charAt(0));
        }
    }

    /**
     * it is programmer-defined toString method
     * @return prints operators on the screen
     */
    @Override
    public String toString() {
        return "Operators in the expression are = " + this.opr.toString();
    }
}


