/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw10_141044085_soner_akar;

import java.util.*;
import java.util.regex.*;

/**
 *
 * @author soner
 */
public class Parenthesis {
    private ArrayList<Character> p;     // Hold parentheses

    /**
     * Non-parameter constructor
     */
    public Parenthesis() {
        this.p = new ArrayList<>();
    }

    /**
     * setter for the operator class
     * @param pr takes character array as ArrayList
     *              then copy to member variable
     */
    public void setP(ArrayList<Character> pr) {        // Setter pr (parenthesis)
        this.p = new ArrayList<>(pr.size());
        Collections.copy(this.p, pr);
    }

    /**
     * getter for parenthesis class
     * @param index specify position
     * @return to get data the specified index
     */
    public char getP(int index) {
        return this.p.get(index);
    }

    /**
     * application of standart ArrayList add method on the class
     * @param pr to add new element to member variable
     */
    public void add(char pr) {        // Add pr (parenthesis)
        this.p.add(pr);
    }

    /**
     * the funtions checks whether right Paranthesis are used
     * @param unified takes a string that includes expression with parenthesis
     * @return true if parenthesis are used rightly, otherwise false
     */
    public boolean CRP(final String unified) {
        Stack<Integer> indices = new Stack<Integer>();
        int len = unified.length();
        boolean result = true;

        for (int i = 0; i < len; i++)
        {
            char ch = unified.charAt(i);
            if (ch == '(')
                indices.push(i);
            else if (ch == ')')
            {
                try
                {
                    indices.pop();
                }
                catch(EmptyStackException e)
                {
                    System.out.println("Unmatched (right parenthesis) ')' at index "+(i+1));
                    result = false;
                }
            }
        }
        while (!indices.isEmpty()) {
            System.out.println("Unmatched  (left parenthesis) '(' at index "+(indices.pop() +1));
            result = false;
        }


        return result;
    }

    /**
     * obtain all parenthesis in a specified expression as a string
     * @param str takes a expression as string to express
     */
    public void holdAllParanthesis(String str) {
        List<String> list = new ArrayList<String>();
        Pattern p = Pattern.compile("[\\(\\)]");
        Matcher m = p.matcher(str);
        while (m.find()) {
            list.add(m.group());
        }

        for (String s : list) {
            this.p.add(s.charAt(0));
        }
    }

    /**
     * it is programmer-defined toString method
     * @return prints parenthesis on the screen
     */
    @Override
    public String toString() {
        return "Paranthesis in the expression are = " + this.p.toString();
    }
}

