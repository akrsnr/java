/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw10_141044085_soner_akar;

/**
 * If input has a division by zero to throw exception
 */
public class SonersException extends Exception
{
    //Parameterless Constructor

    /**
     * Non-parameter constructor
     */
        public SonersException() {}

    //Constructor that accepts a message

    /**
     *
     * @param message put the screen a specified message
     */
        public SonersException(String message)
    {
        super(message);
    }
}