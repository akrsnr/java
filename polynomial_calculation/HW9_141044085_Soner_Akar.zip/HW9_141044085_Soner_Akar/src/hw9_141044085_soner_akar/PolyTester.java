/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw9_141044085_soner_akar;

/**
 *
 * @author soner
 */
public class PolyTester {
    public static void main(String args[]) {

        double[] arr1 = {4,3,2};
        double[] arr2 = {2.17,-3.18,-4.99};
        Polynomial p1 = new Polynomial(arr1);
        Polynomial p2 = new Polynomial(arr2);

        Polynomial p = p1.mul(p2);
        boolean pEq = p1.equal(p2);

        System.out.println();
        System.out.println("p1 =?= p2 = " + pEq);
        System.out.println();
        System.out.println("p1 * p2 = " + p1.mul(p2));
        System.out.println();

        double[] array1 = {1.9, -2.1, 9.0};
        double[] array2 = {3, 1.9, 1.1, -2.8 };

        Polynomial testPol1 = new Polynomial(array1);
        Polynomial testPol2 = new Polynomial(array2);

        System.out.println("testPol1 - testPol2 = " + testPol1.sub(testPol2));
        System.out.println();
        System.out.println("testPol1 + testPol2 = " + testPol1.add(testPol2));
    }
}
