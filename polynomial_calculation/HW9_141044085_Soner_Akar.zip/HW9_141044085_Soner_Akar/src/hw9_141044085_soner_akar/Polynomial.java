package hw9_141044085_soner_akar;


public class Polynomial {

    /**
     * The coefficients of the polynomial equation
     */
    private double[] coff;  // store coefficients

    /**
     * no-arg constructor returns a polynomial of degree 1
     */
    public Polynomial() {
        coff = new double[1];
    }

    /**
     * constructor that takes values in double respectively
     * @param coff values in terms of double array
     */
    public Polynomial(double... coff) {
        this.coff = coff;
    }


    /**
     * set individual element at index
     * @param index set x value to the specified index
     * @param x to be set value in double
     */
    public void setCoff(int index, double x) {
        coff[index] = x;
    }

    /**
     * get individual element at index
     * @param index get the value in the specified index
     */
    public double getCoff(int index) {
        return coff[index];
    }

    /**
     * @return order of the polynomial equation
     */
    public int getDegree() {
        return coff.length- 1;
    }

    /**
     *
     * @return  a copy of the coefficients array.
     */
    public double[] getCoffs() {
        return coff.clone();
    }

    // sum - Arithmetic Operation

    /**
     * Add a polynomial to the instance
     * @param rhs Polynomial to add
     * @return a new polynomial which is the sum of the instance
     */
    public Polynomial add(final Polynomial rhs) {

        double[] first = getCoffs();
        double[] second = rhs.getCoffs();
        if (first.length > second.length) {
            int index = first.length - 1;
            for (int i = second.length - 1; i >= 0; i--) {
                first[index] += second[i];
                index--;
            }
            return new Polynomial(first);
        } else {
            int index = second.length - 1;
            for (int i = first.length - 1; i >= 0; i--) {
                second[index] += first[i];
                index--;
            }
            return new Polynomial(second);
        }
    }

    /**
     * Subtract a polynomial from the instance
     * @param rhs Polynomial to subtract
     * @return a new polynomial which is the difference the instance minus
     */
    public Polynomial sub(final Polynomial rhs) {

        double[] negCoff = new double[rhs.coff.length];
        for (int i = 0; i < rhs.coff.length ; ++i) {
            negCoff[i] = -rhs.coff[i];
        }

        //Polynomial test = new Polynomial(negCoff);
        return add(new Polynomial(negCoff));
    }

    /**
     * Multiply the instance by a polynomial
     * @param rhs olynomial to multiply by
     * @return a new polynomial
     */
    public Polynomial mul(final Polynomial rhs) {

        // number of total terms in multiplied result is coff.length + rhs.coff.length - 1
        int totalLength = coff.length + rhs.coff.length - 1;
        double[] newCoff = new double[totalLength];

        for (int i = 0; i < coff.length; ++i)
            for (int j = 0; j < rhs.coff.length; ++j) {
                newCoff[i + j] += coff[i] * rhs.coff[j];
            }

        return new Polynomial(newCoff);
    }

    /**
     * Evaluate the polynomial equation
     * @param x argument for which the function value should be computed
     * @return the value of the polynomial at the given value
     */
    public double calPol(double x) {

        double result = coff[0];
        for (int i = 1; i <= getDegree(); ++i)
            result = result * x + coff[i];
        return result;

    }

    /**
     * check whether both polynomial equations are same
     * @param rhs argument for which the function value should be compared
     * @return if the equations equal each other true, otherwise false
     */
    public boolean equal(Polynomial rhs) {

        if (getDegree() != rhs.getDegree()) {
            return false;
        }

        for (int i = 0; i <= getDegree(); ++i) {
            if (coff[i] != rhs.coff[i]) {
                return false;
            }
        }
        return true;
    }

    /**
     * @return a string representation of the polynomial equation
     */
    public String toString() {

        String result = "";
        for (int i=0; i<=getDegree(); i++) {
            result += "(" + coff[i] + ")" + (getDegree() - i > 0
                    ? "x" : "") + (getDegree() - i > 1
                    ? "^" + (getDegree() - i) : "") + " + ";
            }
            return result.substring(0, result.length() - 3);
            // -3 remove additional plus character
    }

}
